"""Reference implementation of the custom Qwen3-inspired cybersecurity SLM.

IMPORTANT:
- This is a reconstruction from the architecture details available in the conversation.
- It is not guaranteed to have identical parameter names/forward-pass details to the
  original training code or to load the original best_model.pt checkpoint.
- Validate tensor names/shapes and logits against the original implementation before
  using this model for checkpoint loading or GGUF conversion.
"""
import math
import torch
import torch.nn as nn
import torch.nn.functional as F


class RMSNorm(nn.Module):
    def __init__(self, dim: int, eps: float = 1e-6):
        super().__init__()
        self.eps = eps
        self.weight = nn.Parameter(torch.ones(dim))

    def forward(self, x):
        x_dtype = x.dtype
        x = x.float()
        variance = x.pow(2).mean(dim=-1, keepdim=True)
        x = x * torch.rsqrt(variance + self.eps)
        return (self.weight * x).to(x_dtype)


def compute_rope_params(head_dim: int, theta_base: float = 10000.0,
                        context_length: int = 256, dtype=torch.float32):
    """Build cosine/sine RoPE cache for the half-split rotation convention."""
    inv_freq = 1.0 / (
        theta_base ** (torch.arange(0, head_dim, 2, dtype=dtype) / head_dim)
    )
    positions = torch.arange(context_length, dtype=dtype)
    angles = torch.outer(positions, inv_freq)
    # Repeat each frequency across the two halves used by apply_rope.
    angles = torch.cat((angles, angles), dim=-1)
    return angles.cos(), angles.sin()


def apply_rope(x, cos, sin):
    """Apply half-split rotary embedding; x shape: [B, heads, T, head_dim]."""
    seq_len = x.size(-2)
    cos = cos[:seq_len].to(device=x.device, dtype=x.dtype)[None, None, :, :]
    sin = sin[:seq_len].to(device=x.device, dtype=x.dtype)[None, None, :, :]
    half = x.size(-1) // 2
    x1, x2 = x[..., :half], x[..., half:]
    rotated = torch.cat((-x2, x1), dim=-1)
    return x * cos + rotated * sin


class GroupedQueryAttention(nn.Module):
    def __init__(self, d_model, n_heads, n_kv_groups, max_seq_len,
                 rope_theta=10000.0):
        super().__init__()
        assert d_model % n_heads == 0
        assert n_heads % n_kv_groups == 0
        self.n_heads = n_heads
        self.n_kv_groups = n_kv_groups
        self.head_dim = d_model // n_heads
        self.group_size = n_heads // n_kv_groups

        self.W_query = nn.Linear(d_model, n_heads * self.head_dim, bias=False)
        self.W_key = nn.Linear(d_model, n_kv_groups * self.head_dim, bias=False)
        self.W_value = nn.Linear(d_model, n_kv_groups * self.head_dim, bias=False)
        self.out_proj = nn.Linear(d_model, d_model, bias=False)

        self.q_norm = RMSNorm(self.head_dim)
        self.k_norm = RMSNorm(self.head_dim)

        cos, sin = compute_rope_params(
            self.head_dim, theta_base=rope_theta, context_length=max_seq_len
        )
        self.register_buffer("rope_cos", cos, persistent=False)
        self.register_buffer("rope_sin", sin, persistent=False)

    def forward(self, x):
        batch, seq_len, d_model = x.shape

        q = self.W_query(x).view(
            batch, seq_len, self.n_heads, self.head_dim
        ).transpose(1, 2)
        k = self.W_key(x).view(
            batch, seq_len, self.n_kv_groups, self.head_dim
        ).transpose(1, 2)
        v = self.W_value(x).view(
            batch, seq_len, self.n_kv_groups, self.head_dim
        ).transpose(1, 2)

        q = self.q_norm(q)
        k = self.k_norm(k)
        q = apply_rope(q, self.rope_cos, self.rope_sin)
        k = apply_rope(k, self.rope_cos, self.rope_sin)

        k = k.repeat_interleave(self.group_size, dim=1)
        v = v.repeat_interleave(self.group_size, dim=1)

        scores = torch.matmul(q, k.transpose(-2, -1))
        scores = scores * (self.head_dim ** -0.5)

        causal_mask = torch.triu(
            torch.ones(seq_len, seq_len, device=x.device, dtype=torch.bool),
            diagonal=1
        )
        scores = scores.masked_fill(causal_mask, float("-inf"))
        weights = F.softmax(scores.float(), dim=-1).to(q.dtype)

        context = torch.matmul(weights, v)
        context = context.transpose(1, 2).contiguous().view(
            batch, seq_len, d_model
        )
        return self.out_proj(context)


class SwiGLU(nn.Module):
    def __init__(self, d_model, d_ff):
        super().__init__()
        self.gate_proj = nn.Linear(d_model, d_ff, bias=False)
        self.up_proj = nn.Linear(d_model, d_ff, bias=False)
        self.down_proj = nn.Linear(d_ff, d_model, bias=False)

    def forward(self, x):
        return self.down_proj(F.silu(self.gate_proj(x)) * self.up_proj(x))


class TransformerBlock(nn.Module):
    def __init__(self, d_model, n_heads, n_kv_groups, d_ff, max_seq_len):
        super().__init__()
        self.attn_norm = RMSNorm(d_model)
        self.attention = GroupedQueryAttention(
            d_model, n_heads, n_kv_groups, max_seq_len
        )
        self.ffn_norm = RMSNorm(d_model)
        self.ffn = SwiGLU(d_model, d_ff)

    def forward(self, x):
        x = x + self.attention(self.attn_norm(x))
        x = x + self.ffn(self.ffn_norm(x))
        return x


class Qwen3InspiredConfig:
    def __init__(self, vocab_size=151643, d_model=256, n_heads=8,
                 n_kv_groups=2, n_layers=4, d_ff=768, max_seq_len=256):
        self.vocab_size = vocab_size
        self.d_model = d_model
        self.n_heads = n_heads
        self.n_kv_groups = n_kv_groups
        self.n_layers = n_layers
        self.d_ff = d_ff
        self.max_seq_len = max_seq_len


class Qwen3InspiredModel(nn.Module):
    def __init__(self, config: Qwen3InspiredConfig):
        super().__init__()
        self.config = config
        self.tok_emb = nn.Embedding(config.vocab_size, config.d_model)
        self.blocks = nn.ModuleList([
            TransformerBlock(
                config.d_model, config.n_heads, config.n_kv_groups,
                config.d_ff, config.max_seq_len
            )
            for _ in range(config.n_layers)
        ])
        self.final_norm = RMSNorm(config.d_model)
        self.out_head = nn.Linear(
            config.d_model, config.vocab_size, bias=False
        )

    def forward(self, input_ids, targets=None):
        x = self.tok_emb(input_ids) * math.sqrt(self.config.d_model)
        for block in self.blocks:
            x = block(x)
        x = self.final_norm(x)
        logits = self.out_head(x)

        loss = None
        if targets is not None:
            loss = F.cross_entropy(
                logits.reshape(-1, logits.size(-1)),
                targets.reshape(-1),
                ignore_index=-100
            )
        return logits, loss


if __name__ == "__main__":
    cfg = Qwen3InspiredConfig()
    model = Qwen3InspiredModel(cfg)
    sample = torch.randint(0, cfg.vocab_size, (2, 32))
    logits, loss = model(sample)
    print("Output shape:", tuple(logits.shape))
    print("Parameters:", sum(p.numel() for p in model.parameters()))
