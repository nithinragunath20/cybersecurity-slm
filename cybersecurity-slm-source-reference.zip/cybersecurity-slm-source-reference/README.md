# Cybersecurity SLM — source reference

This repository contains a **reference reconstruction** of the custom Qwen3-inspired
decoder-only Transformer architecture described in the project notes.

## Architecture

- Vocabulary size: 151,643
- Model dimension: 256
- Transformer layers: 4
- Attention heads: 8
- KV groups: 2 (grouped-query attention)
- Feed-forward dimension: 768
- Context length: 256
- Components: RoPE, Q/K RMSNorm, RMSNorm, GQA, SwiGLU, causal self-attention

## Important provenance note

This is not a byte-for-byte copy of the original training project. The original
training notebook, preprocessing pipeline, tokenizer setup, and exact checkpoint
state-dict naming were not available in the conversation. This reference model
must not be assumed to load `best_model.pt` or reproduce the original model's
logits until verified against the original source.

The project notes describe an 80,658,432-parameter trained model and report a
best validation loss of 0.5374 at iteration 76,000. Those results belong to the
original training run, not to this reference implementation.

## Run a shape smoke test

```bash
python -m pip install -r requirements.txt
python src/model.py
```

## Dataset

Project dataset: https://huggingface.co/datasets/nithinragunath/DT

The dataset is described as DARPA Transparent Computing CDM18 telemetry with
1,000,000 records split into 700,000 training, 150,000 validation, and 150,000
test records. The records do not provide explicit malicious/benign labels, so
this project should not be described as a validated malware classifier.

## Model card

Project model page: https://huggingface.co/nithinragunath/cybersecurity-slm
